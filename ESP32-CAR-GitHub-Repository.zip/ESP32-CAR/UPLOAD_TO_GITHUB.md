# Upload this repository to GitHub

GitHub does not automatically extract a ZIP file. Extract the ZIP on your laptop first.

## Upload steps

1. Right-click `ESP32-CAR-GitHub-Repository.zip` and select **Extract All**.
2. Open the extracted `ESP32-CAR` folder.
3. Open your `ESP32-car` repository on GitHub.
4. Select **Code → Add file → Upload files**.
5. Drag all files and folders from inside the extracted `ESP32-CAR` folder into the upload area.
6. Wait until every file appears in the list.
7. Enter the commit message: `Add complete ESP32 car project`.
8. Select **Commit directly to the main branch**.
9. Click **Commit changes**.

Uploading this package will update the existing `README.md` and add the other project files. Keep the folder structure unchanged so the links and image work.

## Expected top-level files

```text
README.md
HARDWARE.md
WIRING.md
WORKING.md
SETUP.md
TESTING.md
TROUBLESHOOTING.md
IMAGES.md
VIDEOS.md
SOURCES.md
LICENSE
.gitignore
firmware/
images/
```

[Back to README](README.md)
