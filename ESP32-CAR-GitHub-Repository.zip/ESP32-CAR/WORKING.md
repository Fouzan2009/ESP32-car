# How the ESP32 car works

## Control flow

1. The ESP32 starts a Bluetooth Classic Serial Port Profile device named `ESP32-CAR`.
2. An Android Bluetooth terminal or controller app connects to the ESP32.
3. The app sends a single character such as `F`, `B`, `L`, `R`, or `S`.
4. The ESP32 converts that command into signed left- and right-motor speeds.
5. Direction pins control the L298N H-bridges.
6. PWM on `ENA` and `ENB` controls speed.
7. The car stops when it receives `S`, loses the Bluetooth connection, receives an unknown command, or does not receive another movement command within 1.5 seconds.

## Motor actions

| Action | Left motors | Right motors |
|---|---|---|
| Forward | Forward | Forward |
| Backward | Backward | Backward |
| Left | Backward | Forward |
| Right | Forward | Backward |
| Forward-left | Slower forward | Forward |
| Forward-right | Forward | Slower forward |
| Stop | Off | Off |

## Speed control

Commands `0` through `9` set the selected PWM speed. `0` stops the car and `9` selects maximum PWM. The default startup speed is approximately 75%.

## Safety timeout

The controller app should repeat the current movement character while a movement button is held. If it sends a movement character only once, the car stops after 1.5 seconds. This timeout limits continued movement after a connection or app problem.

[Back to README](README.md)
