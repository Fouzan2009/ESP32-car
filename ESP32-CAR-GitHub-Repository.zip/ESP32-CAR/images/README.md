# Images folder

This folder stores the wiring diagram and future project photographs.

- `ESP32-CAR-WIRING.png`: wiring reference supplied for the project.
- Add real build photographs after physical testing.
