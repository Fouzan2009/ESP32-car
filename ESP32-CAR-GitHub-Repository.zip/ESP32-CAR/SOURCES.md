# Official technical references

- [Espressif Arduino-ESP32 installation guide](https://docs.espressif.com/projects/arduino-esp32/en/latest/installing.html)
- [Espressif Arduino-ESP32 Bluetooth documentation](https://docs.espressif.com/projects/arduino-esp32/en/latest/api/bluetooth.html)
- [Espressif Arduino-ESP32 LEDC PWM documentation](https://docs.espressif.com/projects/arduino-esp32/en/latest/api/ledc.html)
- [Espressif Arduino-ESP32 tools menu guide](https://docs.espressif.com/projects/arduino-esp32/en/latest/guides/tools_menu.html)

These links are technical references. Follow the exact pin table in [WIRING.md](WIRING.md) for this project.

[Back to README](README.md)
