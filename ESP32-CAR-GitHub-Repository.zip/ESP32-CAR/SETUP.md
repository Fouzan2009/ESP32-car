# Setup instructions

## 1. Install Arduino IDE

Download and install Arduino IDE from the official Arduino website.

## 2. Install ESP32 board support

1. Open Arduino IDE.
2. Open **File → Preferences**.
3. Add this URL to **Additional Boards Manager URLs**:

   `https://espressif.github.io/arduino-esp32/package_esp32_index.json`

4. Open **Tools → Board → Boards Manager**.
5. Search for `esp32` and install **esp32 by Espressif Systems**.
6. Restart Arduino IDE if requested.

## 3. Open the firmware

Open:

`firmware/ESP32_RC_Car/ESP32_RC_Car.ino`

## 4. Select the board and port

1. Connect the ESP32 with a USB data cable.
2. Select **Tools → Board → ESP32 Arduino → ESP32 Dev Module**.
3. Select the correct COM port under **Tools → Port**.

If your exact board has a matching entry, select that entry instead.

## 5. Upload safely

1. Switch off or disconnect motor power.
2. Click **Verify**.
3. Click **Upload**.
4. If the upload waits at `Connecting...`, hold the ESP32 **BOOT** button until uploading starts, then release it.
5. Open Serial Monitor at `115200` baud to check the startup message.

## 6. Pair the phone

1. Use an Android phone with Bluetooth enabled.
2. Open Bluetooth settings and find `ESP32-CAR`.
3. Pair and connect using a Bluetooth serial terminal/controller app.
4. Configure app buttons to send uppercase characters: `F`, `B`, `L`, `R`, and `S`.
5. Configure held movement buttons to repeat their character when possible.

## 7. First movement test

1. Raise all wheels from the floor.
2. Switch on motor power.
3. Send `S` first.
4. Send `F`, `B`, `L`, and `R` one at a time for a short test.
5. Complete [TESTING.md](TESTING.md) before driving on the floor.

[Back to README](README.md)
