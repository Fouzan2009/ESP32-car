#include <Arduino.h>
#include <BluetoothSerial.h>
#include <esp_arduino_version.h>

#if !defined(CONFIG_BT_ENABLED) || !defined(CONFIG_BLUEDROID_ENABLED)
#error Bluetooth is not enabled for the selected board.
#endif

#if !defined(CONFIG_BT_SPP_ENABLED)
#error Bluetooth Classic SPP is unavailable. Select an original ESP32 board, not ESP32-S3 or ESP32-C3.
#endif

BluetoothSerial SerialBT;

// L298N connections from WIRING.md
constexpr uint8_t ENA_PIN = 32;
constexpr uint8_t IN1_PIN = 14;
constexpr uint8_t IN2_PIN = 27;
constexpr uint8_t IN3_PIN = 26;
constexpr uint8_t IN4_PIN = 25;
constexpr uint8_t ENB_PIN = 33;

constexpr uint32_t PWM_FREQUENCY = 12000;
constexpr uint8_t PWM_RESOLUTION = 8;
constexpr uint8_t LEFT_PWM_CHANNEL = 0;
constexpr uint8_t RIGHT_PWM_CHANNEL = 1;
constexpr uint32_t COMMAND_TIMEOUT_MS = 1500;
constexpr char BLUETOOTH_NAME[] = "ESP32-CAR";

int driveSpeed = 190;
bool movementActive = false;
uint32_t lastMovementCommandMs = 0;

void writeMotorPwm(uint8_t pin, uint8_t channel, uint8_t duty) {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(pin, duty);
#else
  ledcWrite(channel, duty);
#endif
}

void setupPwm() {
#if ESP_ARDUINO_VERSION_MAJOR >= 3
  if (!ledcAttach(ENA_PIN, PWM_FREQUENCY, PWM_RESOLUTION) ||
      !ledcAttach(ENB_PIN, PWM_FREQUENCY, PWM_RESOLUTION)) {
    Serial.println("PWM setup failed");
  }
#else
  ledcSetup(LEFT_PWM_CHANNEL, PWM_FREQUENCY, PWM_RESOLUTION);
  ledcSetup(RIGHT_PWM_CHANNEL, PWM_FREQUENCY, PWM_RESOLUTION);
  ledcAttachPin(ENA_PIN, LEFT_PWM_CHANNEL);
  ledcAttachPin(ENB_PIN, RIGHT_PWM_CHANNEL);
#endif
}

void setOneMotor(uint8_t in1, uint8_t in2, uint8_t pwmPin,
                 uint8_t pwmChannel, int signedSpeed) {
  signedSpeed = constrain(signedSpeed, -255, 255);

  if (signedSpeed == 0) {
    digitalWrite(in1, LOW);
    digitalWrite(in2, LOW);
    writeMotorPwm(pwmPin, pwmChannel, 0);
    return;
  }

  const bool forward = signedSpeed > 0;
  digitalWrite(in1, forward ? HIGH : LOW);
  digitalWrite(in2, forward ? LOW : HIGH);
  writeMotorPwm(pwmPin, pwmChannel, abs(signedSpeed));
}

void drive(int leftSpeed, int rightSpeed) {
  setOneMotor(IN1_PIN, IN2_PIN, ENA_PIN, LEFT_PWM_CHANNEL, leftSpeed);
  setOneMotor(IN3_PIN, IN4_PIN, ENB_PIN, RIGHT_PWM_CHANNEL, rightSpeed);
}

void stopCar() {
  drive(0, 0);
  movementActive = false;
}

bool runCommand(char command) {
  command = static_cast<char>(toupper(static_cast<unsigned char>(command)));
  const int slowSpeed = driveSpeed / 2;

  if (command >= '0' && command <= '9') {
    if (command == '0') {
      driveSpeed = 0;
      stopCar();
    } else {
      driveSpeed = map(command - '0', 1, 9, 80, 255);
    }
    Serial.printf("Speed: %d\n", driveSpeed);
    return true;
  }

  switch (command) {
    case 'F': drive( driveSpeed,  driveSpeed); break;
    case 'B': drive(-driveSpeed, -driveSpeed); break;
    case 'L': drive(-driveSpeed,  driveSpeed); break;
    case 'R': drive( driveSpeed, -driveSpeed); break;
    case 'G': drive( slowSpeed,   driveSpeed); break;
    case 'I': drive( driveSpeed,  slowSpeed); break;
    case 'H': drive(-slowSpeed,  -driveSpeed); break;
    case 'J': drive(-driveSpeed, -slowSpeed); break;
    case 'S': stopCar(); return true;
    default:  stopCar(); return false;
  }

  movementActive = true;
  lastMovementCommandMs = millis();
  return true;
}

void setup() {
  Serial.begin(115200);

  pinMode(IN1_PIN, OUTPUT);
  pinMode(IN2_PIN, OUTPUT);
  pinMode(IN3_PIN, OUTPUT);
  pinMode(IN4_PIN, OUTPUT);

  setupPwm();
  stopCar();

  if (!SerialBT.begin(BLUETOOTH_NAME)) {
    Serial.println("Bluetooth startup failed");
    while (true) {
      stopCar();
      delay(1000);
    }
  }

  Serial.println("ESP32 car ready");
  Serial.printf("Bluetooth device: %s\n", BLUETOOTH_NAME);
}

void loop() {
  if (!SerialBT.hasClient()) {
    stopCar();
  }

  while (SerialBT.available()) {
    const char command = static_cast<char>(SerialBT.read());
    if (command == '\n' || command == '\r' || command == ' ') {
      continue;
    }

    const bool recognized = runCommand(command);
    Serial.printf("Command: %c (%s)\n", command,
                  recognized ? "accepted" : "stopped: unknown");
  }

  if (movementActive &&
      static_cast<uint32_t>(millis() - lastMovementCommandMs) > COMMAND_TIMEOUT_MS) {
    stopCar();
    Serial.println("Stopped: command timeout");
  }

  delay(5);
}
