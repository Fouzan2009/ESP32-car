# Hardware components

## Required parts

| Quantity | Component | Purpose |
|---:|---|---|
| 1 | ESP32-WROOM development board | Receives Bluetooth commands and controls the driver |
| 1 | L298N dual H-bridge motor driver module | Drives the left and right motor groups |
| 4 | DC geared motors | Moves the car |
| 4 | Wheels | Attach to the motor shafts |
| 1 | Four-wheel robot chassis | Holds the parts |
| 1 | Motor battery pack | Powers the motors through the L298N |
| 1 | Regulated 5 V supply or buck converter | Recommended power source for the ESP32 |
| 1 | Power switch | Disconnects motor power quickly |
| 1 | Fuse suitable for the measured motor current | Protects the motor-power circuit |
| Several | Jumper wires and suitable motor wires | Electrical connections |
| 1 | USB data cable | Programs the ESP32 |

## Board compatibility

Use an original ESP32 board that supports Bluetooth Classic, such as an ESP32-WROOM DevKit. This firmware is not for ESP32-S3, ESP32-C3, or boards without Bluetooth Classic SPP.

## Motor grouping

- Connect the two left motors as one parallel group to L298N `OUT1` and `OUT2`.
- Connect the two right motors as one parallel group to L298N `OUT3` and `OUT4`.
- Keep both motors in each group in the same physical driving direction.
- If one motor spins the wrong way, disconnect power and reverse that motor's two wires.

## Power requirements

The motor battery voltage must match the voltage rating of the motors. Check the combined running and stall current of both motors on each L298N channel. Do not exceed the ratings of the motor driver module, wires, switch, battery, or fuse.

The L298N has a noticeable voltage drop and may become hot. If it overheats or the car is weak, reduce the load and check motor current, wheel alignment, supply voltage, and wiring.

## Important power rules

- Never power a motor from an ESP32 GPIO, `3V3`, or USB pin.
- Use a regulated 5 V supply for the ESP32 `VIN/5V` pin, or power the ESP32 by USB.
- Connect ESP32 GND, L298N GND, and motor battery negative together.
- Disconnect all power before changing a wire.
- Begin testing with all wheels raised from the floor.

[Back to README](README.md)
