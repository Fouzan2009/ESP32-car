# Wiring connections

The table below is the source of truth for this repository. It matches the supplied wiring layout.

## ESP32 to L298N

Remove the L298N `ENA` and `ENB` jumper caps when GPIO32 and GPIO33 are connected for PWM speed control.

| L298N pin | ESP32 pin | Function |
|---|---:|---|
| `ENA` | GPIO32 | Left motor speed (PWM) |
| `IN1` | GPIO14 | Left motor direction 1 |
| `IN2` | GPIO27 | Left motor direction 2 |
| `IN3` | GPIO26 | Right motor direction 1 |
| `IN4` | GPIO25 | Right motor direction 2 |
| `ENB` | GPIO33 | Right motor speed (PWM) |
| `GND` | GND | Common ground |

## Motors to L298N

| L298N output | Connection |
|---|---|
| `OUT1` and `OUT2` | Two left motors connected as a parallel pair |
| `OUT3` and `OUT4` | Two right motors connected as a parallel pair |

If a complete side moves backward when it should move forward, disconnect power and swap `OUT1/OUT2` for the left side or `OUT3/OUT4` for the right side. If only one motor in a pair is reversed, swap only that motor's two wires.

## Power connections

### Recommended method

| Power connection | Destination |
|---|---|
| Motor battery positive | L298N motor-supply input marked `12V`, `Vs`, or `Vmotor`, through a switch and suitable fuse |
| Motor battery negative | L298N `GND` |
| Regulated 5 V output | ESP32 `VIN/5V` |
| Regulated supply ground | ESP32 `GND` and L298N `GND` |

The terminal marked `12V` on common L298N modules is the motor-supply input name; it does not mean every motor must use 12 V. Use the voltage specified for your motors.

### About the L298N 5 V terminal

Some L298N modules can provide regulated 5 V only under specific jumper and motor-supply conditions. Do not assume that the terminal is always a safe output. A separate 5 V buck converter or USB supply is recommended. If you decide to use the L298N 5 V terminal, first check the exact module instructions and measure the terminal with a multimeter before connecting the ESP32.

## Assembly order

1. Keep the battery and USB cable disconnected.
2. Connect the six ESP32 control pins to the L298N.
3. Connect both left motors to `OUT1/OUT2`.
4. Connect both right motors to `OUT3/OUT4`.
5. Connect all grounds together.
6. Connect the regulated ESP32 supply.
7. Upload the firmware while motor power remains off.
8. Raise all wheels from the floor.
9. Connect motor power through the switch and fuse.
10. Test `S`, `F`, `B`, `L`, and `R` briefly.

## Diagram

![ESP32 car wiring diagram](images/ESP32-CAR-WIRING.png)

[Back to README](README.md)
