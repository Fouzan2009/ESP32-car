# Problems and solutions

## ESP32 does not appear in Bluetooth search

- Confirm the board is an original ESP32 model with Bluetooth Classic support.
- ESP32-S3 and ESP32-C3 cannot run this Bluetooth Classic SPP sketch.
- Confirm the sketch uploaded and Serial Monitor shows `Bluetooth device: ESP32-CAR`.
- Restart Bluetooth on the phone and reset the ESP32.

## Code does not compile with BluetoothSerial

Select **ESP32 Dev Module** or the correct original ESP32 board. A compile message saying SPP is unavailable usually means the selected target does not support Bluetooth Classic.

## Upload remains on `Connecting...`

- Check that the USB cable supports data.
- Select the correct COM port.
- Disconnect motor power.
- Hold **BOOT**, begin uploading, and release BOOT when writing starts.

## Bluetooth connects but motors do not move

- Confirm the app sends uppercase characters.
- Confirm `ENA` and `ENB` jumpers are removed when GPIO32 and GPIO33 are connected.
- Check L298N motor power and common ground.
- Check the six control connections against [WIRING.md](WIRING.md).
- Send speed command `9`, then send `F`.

## Car moves briefly and stops

The safety timeout stops motion after 1.5 seconds. Configure the controller app to repeat the movement character while the button is held. You may change `COMMAND_TIMEOUT_MS` in the sketch after testing the stop behavior.

## ESP32 resets when motors start

- Power the ESP32 from a stable regulated 5 V source or USB.
- Keep motor power separate from ESP32 power while sharing ground.
- Check battery voltage under load.
- Shorten motor-current wires and follow the motor-driver module's capacitor guidance.

## One motor or one side moves backward

Disconnect power. Reverse the two wires of the affected motor. Do not change wiring while powered.

## Left and right controls are reversed

Swap the left and right motor output groups, or exchange the left and right pin definitions in the sketch.

## L298N becomes very hot

Stop testing and disconnect power. Check for stalled motors, excessive total current, mechanical friction, wrong battery voltage, loose terminals, or a short circuit. The L298N also loses voltage internally and is inefficient compared with modern MOSFET drivers.

## Car is slow

- Charge or replace the battery.
- Check the motor voltage at the L298N outputs under load.
- Check wheels and gearboxes for friction.
- Confirm command `9` is selected.
- Remember that the L298N causes a voltage drop.

[Back to README](README.md)
