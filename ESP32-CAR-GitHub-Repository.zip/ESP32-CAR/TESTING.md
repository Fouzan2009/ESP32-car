# Hardware testing checklist

**Current status: physical hardware testing is pending.** Mark a box only after performing that test on the real car.

## Before power

- [ ] ESP32 board is an original ESP32 model with Bluetooth Classic support.
- [ ] Motor battery voltage matches the motor rating.
- [ ] Motor current is within the driver, battery, switch, fuse, and wire ratings.
- [ ] ESP32 and L298N share a common ground.
- [ ] Motor supply is not connected to ESP32 `3V3`.
- [ ] L298N `ENA` and `ENB` jumpers are removed for PWM control.
- [ ] No loose wire or short circuit is visible.
- [ ] All wheels are raised from the floor.

## Functional tests

- [ ] Firmware compiles for **ESP32 Dev Module**.
- [ ] Firmware uploads successfully.
- [ ] Serial Monitor shows the startup message at `115200` baud.
- [ ] Android phone finds `ESP32-CAR`.
- [ ] Bluetooth app connects.
- [ ] `S` keeps every motor stopped.
- [ ] `F` moves all wheels forward.
- [ ] `B` moves all wheels backward.
- [ ] `L` turns left.
- [ ] `R` turns right.
- [ ] Speed commands `0`–`9` change the speed.
- [ ] Releasing a button stops the car.
- [ ] Disconnecting Bluetooth stops the car.
- [ ] Command silence stops the car after approximately 1.5 seconds.

## Load test

- [ ] Car moves correctly on the floor at low speed.
- [ ] ESP32 does not reset when motors start.
- [ ] L298N and wires remain within a safe temperature.
- [ ] Motors do not stall during normal driving.
- [ ] Physical power switch can stop motor power immediately.

## Test record

| Date | Battery | Test | Result | Notes |
|---|---|---|---|---|
| | | | | |

[Back to README](README.md)
