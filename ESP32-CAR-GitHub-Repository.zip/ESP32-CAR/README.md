# ESP32 CAR

A Bluetooth-controlled four-wheel car built with an ESP32-WROOM development board, an L298N motor driver, and four DC geared motors.

![ESP32 car wiring diagram](images/ESP32-CAR-WIRING.png)

## Project status

**Documentation and firmware prepared. Physical hardware testing is pending.**

## Features

- Android control through Bluetooth Classic
- Forward, backward, left, right, and stop commands
- Adjustable motor speed using PWM
- Four motors arranged as left and right motor pairs
- Automatic stop after Bluetooth disconnection or command timeout
- Clear wiring, setup, testing, and troubleshooting guides

## Bluetooth commands

| Command | Action |
|---|---|
| `F` | Move forward |
| `B` | Move backward |
| `L` | Turn left |
| `R` | Turn right |
| `S` | Stop |
| `G` | Forward-left |
| `I` | Forward-right |
| `H` | Backward-left |
| `J` | Backward-right |
| `0`–`9` | Set speed from stop to maximum |

## Project documentation

| File | Contents |
|---|---|
| [HARDWARE.md](HARDWARE.md) | Required components and power information |
| [WIRING.md](WIRING.md) | Exact ESP32, L298N, motor, and power connections |
| [WORKING.md](WORKING.md) | How Bluetooth commands control the car |
| [SETUP.md](SETUP.md) | Arduino IDE, upload, pairing, and app setup |
| [TESTING.md](TESTING.md) | Safe test procedure and results checklist |
| [TROUBLESHOOTING.md](TROUBLESHOOTING.md) | Common problems and solutions |
| [IMAGES.md](IMAGES.md) | Wiring diagram and project photo section |
| [VIDEOS.md](VIDEOS.md) | Demonstration video section |
| [UPLOAD_TO_GITHUB.md](UPLOAD_TO_GITHUB.md) | How to upload this package to GitHub |
| [SOURCES.md](SOURCES.md) | Official technical references |

## Firmware

Open this Arduino sketch:

[`firmware/ESP32_RC_Car/ESP32_RC_Car.ino`](firmware/ESP32_RC_Car/ESP32_RC_Car.ino)

The code is intended for an **original ESP32-WROOM/ESP32 Dev Module** that supports Bluetooth Classic SPP. The ESP32-S3 and ESP32-C3 do not support this `BluetoothSerial` SPP sketch.

## Quick start

1. Disconnect motor power and raise the wheels from the floor.
2. Complete the connections in [WIRING.md](WIRING.md).
3. Install ESP32 board support in Arduino IDE.
4. Open and upload `ESP32_RC_Car.ino`.
5. Pair an Android phone with the Bluetooth device named `ESP32-CAR`.
6. Use a Bluetooth terminal/controller app to send the commands above.
7. Complete every check in [TESTING.md](TESTING.md) before normal driving.

## Author

**Fouzan K**

## License

This project is released under the [MIT License](LICENSE).
